package com.wraith.netgrif;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetgrifApplicationTests {

    @Test
    void contextLoads() {
    }

}
