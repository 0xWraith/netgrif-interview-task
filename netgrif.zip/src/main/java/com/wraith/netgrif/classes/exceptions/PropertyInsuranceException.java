package com.wraith.netgrif.classes.exceptions;

public class PropertyInsuranceException extends Exception
{
    public PropertyInsuranceException(String message) { super(message); }
}
