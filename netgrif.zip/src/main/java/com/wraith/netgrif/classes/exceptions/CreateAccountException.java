package com.wraith.netgrif.classes.exceptions;

public class CreateAccountException extends Exception
{
    public CreateAccountException(String message) { super(message); }
}
