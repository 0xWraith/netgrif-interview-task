package com.wraith.netgrif.classes.exceptions;

public class TravelInsuranceException extends Exception
{
    public TravelInsuranceException(String message) { super(message); }
}
